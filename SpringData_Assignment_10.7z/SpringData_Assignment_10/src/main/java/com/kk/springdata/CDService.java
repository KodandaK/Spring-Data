package com.kk.springdata;

import java.util.List;

public interface CDService {
	
	List<CD> cdByPublisher(String cdPublisher);
	
	List<CD> findAllCD();

}
